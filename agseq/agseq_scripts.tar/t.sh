vcfs=($@);

unset vcfs[0]

echo ${vcfs[*]}
