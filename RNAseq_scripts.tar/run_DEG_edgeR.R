library(edgeR)

args = commandArgs(trailingOnly=TRUE)
file = args[1]
#file="counts_all_formatted.txt"
count_data = read.table(file, header=T, sep="\t")

row.names(count_data) = count_data[,1]
count_data = count_data[, 7:ncol(count_data)]

samples = colnames(count_data)

# One bad sample
# bad_sample=c("Ch48_C_2")
# bad_sample_index = which(samples == bad_sample)
# 
# count_data = count_data[, -1 * bad_sample_index]

group = gsub("_\\d+$", "", colnames(count_data))

group = as.factor(group)

group_levels = levels(group)

# put all into DGElist
y = DGEList(count = count_data, group = group)
y <- calcNormFactors(y)
design <- model.matrix(~0+group)
y <- estimateDisp(y,design)
fit <- glmQLFit(y,design)

logcpm = cpm(y, log=TRUE)
write.csv(logcpm, file="logCPM.csv")

# perfrom quasi-likelihood F-tests
# edgeR offers many variants on analyses. The glm approach is more popular than the classic approach as it offers great flexibilities. 
# There are two testing methods under the glm framework: likelihood ratio test and quasi-likelihood F-test. 
# The quasi-likelihood method is highly recommended for differential expression analyses of bulk RNA-seq data as it gives stricter
# error rate control by accounting for the uncertainty in dispersion estimation.
# The likelihoodratio test can be useful in some special cases such as single cell RNA-seq and datasets with no replicates

##control = c(rep("Ch24_M", 3), "Ch4_M", "Ch8_M", "Sit24_M", "Ch0_M", "Ch24_M")
##test = c("Sit24_M", "Stg24_M", "Cmp24_M", "Sit4_M", "Sit8_M", "SCh48_M", "Ch24_M", "Ch48_M")

#control = c(rep("MX1", length(group_levels)))
control = group_levels
test = group_levels

comps = character(length(control) * (length(control)-1)/2)
m=0
for (i in 1:(length(control)-1)){
  for (j in (i+1):length(test)){
    m = m + 1
    if (control[i] == test[j]){next}
    comp = paste(control[i], "VS", test[j], sep="_")
    comps[m] = comp
    print(comp)
    ##
    contrast = numeric(length(group_levels))
    contrast[which(group_levels == control[i])] = -1
    contrast[which(group_levels == test[j])] = 1
    ## perform the test
    qlf = glmQLFTest(fit, contrast = contrast)
    #output 
    output = paste(comp, "csv", sep=".")
    tb  =  qlf$table
    tb$FDR = p.adjust(tb$PValue, "fdr")
    tb = tb[order(tb$PValue), ]
    
    write.csv(tb, file=output)
 }   
}



